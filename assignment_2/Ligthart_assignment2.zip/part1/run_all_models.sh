python3 train.py --model_type RNN --input_length 5

python3 train.py --model_type LSTM --input_length 5

python3 train.py --model_type RNN --input_length 6

python3 train.py --model_type LSTM --input_length 6

python3 train.py --model_type RNN --input_length 7

python3 train.py --model_type LSTM --input_length 7

python3 train.py --model_type RNN --input_length 8

python3 train.py --model_type LSTM --input_length 8

python3 train.py --model_type RNN --input_length 9

python3 train.py --model_type LSTM --input_length 9

python3 train.py --model_type RNN --input_length 10

python3 train.py --model_type LSTM --input_length 10
